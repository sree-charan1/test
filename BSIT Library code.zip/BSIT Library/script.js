const searchInput = document.getElementById('search-input');
const searchResults = document.getElementById('search-results');

searchInput.addEventListener('input', searchBooks);

function searchBooks() {
  const searchTerm = searchInput.value.toLowerCase();
  fetch('https://raw.githubusercontent.com/sree-charan1/test/main/books.json')
    .then(response => response.json())
    .then(books => {
      const filteredBooks = books.filter(book => {
        return (
          book.Author.toLowerCase().includes(searchTerm) ||
          book.Title.toLowerCase().includes(searchTerm) ||
          book.Edition.toLowerCase().includes(searchTerm) ||
          book.Publisher.toLowerCase().includes(searchTerm)
        );
      });
      displaySearchResults(filteredBooks);
    });
}
function displaySearchResults(books) {
  if (books.length === 0) {
    searchResults.innerHTML = `
      <div class="no-results">
        <h2>No search results found</h2>
        <p>Try searching for something else</p>
      </div>
    `;
  } else {
    const html = `
      <table class="search-results-table">
        <thead>
          <tr>
            <th>Accession Number</th>
            <th>Title</th>
            <th>Author</th>
            <th>Edition</th>
            <th>Publisher</th>
          </tr>
        </thead>
        <tbody>
          ${books.map(book => {
            return `
              <tr>
                <td>${book.AccessionNumber}</td>
                <td>${book.Title}</td>
                <td>${book.Author}</td>
                <td>${book.Edition}</td>
                <td>${book.Publisher}</td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    `;
    searchResults.innerHTML = html;
  }
}