const searchInput = document.getElementById('search-input');
const bookList = document.getElementById('book-list');

fetch('books.json')
  .then(response => response.json())
  .then(data => {
    const bookData = data;
    searchInput.addEventListener('input', searchBooks);

    function searchBooks() {
      const searchTerm = searchInput.value.toLowerCase();
      const filteredBooks = bookData.filter(book => {
        return (
          book.title.toLowerCase().includes(searchTerm) ||
          book.author.toLowerCase().includes(searchTerm) ||
          book.publisher.toLowerCase().includes(searchTerm)
        );
      });
      renderBookList(filteredBooks);
    }

    function renderBookList(books) {
      bookList.innerHTML = '';
      books.forEach(book => {
        const bookListItem = document.createElement('li');
        bookListItem.textContent = `${book.title} by ${book.author} (${book.publisher})`;
        bookList.appendChild(bookListItem);
      });
    }
  });